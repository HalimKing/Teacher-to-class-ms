import { useState, useEffect, useCallback } from 'react';
import { GoogleMap, LoadScript, Marker, Circle } from '@react-google-maps/api';
import { MapPin, Clock, CheckCircle, XCircle, RefreshCw, Loader2 } from 'lucide-react';

interface ClassLocation {
  id: number;
  name: string;
  building: string;
  room: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  radius: number;
}

interface AttendanceRecord {
  id: number;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: 'present' | 'absent' | 'late' | 'early_departure';
  location_match: boolean;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

const classLocations: ClassLocation[] = [
  {
    id: 1,
    name: 'Data Structures',
    building: 'Building A',
    room: 'A-101',
    coordinates: { lat: 40.7128, lng: -74.0060 },
    radius: 100
  },
  {
    id: 2,
    name: 'Algorithms Lab',
    building: 'Building B',
    room: 'B-205',
    coordinates: { lat: 40.7128, lng: -74.0062 },
    radius: 100
  },
  {
    id: 3,
    name: 'Database Systems',
    building: 'Building C',
    room: 'C-102',
    coordinates: { lat: 40.7126, lng: -74.0058 },
    radius: 100
  }
];

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371e3;
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a =
    Math.sin(Δφ / 2) ** 2 +
    Math.cos(φ1) *
    Math.cos(φ2) *
    Math.sin(Δλ / 2) ** 2;

  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
};

const containerStyle = {
  width: '100%',
  height: '400px'
};

export default function TeacherAttendancePage() {
  const [selectedClass, setSelectedClass] = useState<ClassLocation | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  const [isWithinRange, setIsWithinRange] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 5.6037, lng: -0.1870 }); // Default to Accra

  const [currentStatus, setCurrentStatus] =
    useState<'not_checked_in' | 'checked_in' | 'checked_out'>('not_checked_in');

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [checkInTime, setCheckInTime] = useState<string | null>(null);

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  // Auto-fetch location on mount
  useEffect(() => {
    getCurrentLocation();
  }, []);

  console.log('API Key:', import.meta.env.VITE_GOOGLE_MAPS_API_KEY);

  // Update map center when user location or selected class changes
  useEffect(() => {
    if (userLocation) {
      setMapCenter(userLocation);
    } else if (selectedClass) {
      setMapCenter(selectedClass.coordinates);
    }
  }, [userLocation, selectedClass]);

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      return;
    }

    setIsLoadingLocation(true);
    setLocationError(null);

    

navigator.geolocation.getCurrentPosition(
  (position) => {
    console.log(position.coords.latitude, position.coords.longitude);
  },
  (error) => {
    console.error(error);
  },
  {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0,
  }
);



    

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy
        };

        setUserLocation(loc);
        setIsLoadingLocation(false);

        if (selectedClass) {
          checkLocationAgainstClass(loc);
        }
      },
      (error) => {
        setIsLoadingLocation(false);
        let errorMessage = "Unable to retrieve your location";
        
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location permission denied. Please enable location access.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable.";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out.";
            break;
        }
        
        setLocationError(errorMessage);
      },
      { 
        enableHighAccuracy: true, 
        timeout: 50000, 
        maximumAge: 0 
      }
    );
  };

  const checkLocationAgainstClass = (location: { lat: number; lng: number }) => {
    if (!selectedClass) return;

    const d = calculateDistance(
      location.lat,
      location.lng,
      selectedClass.coordinates.lat,
      selectedClass.coordinates.lng
    );

    setDistance(d);
    setIsWithinRange(d <= selectedClass.radius);
  };

  const handleClassSelect = (cls: ClassLocation) => {
    setSelectedClass(cls);

    if (userLocation) {
      checkLocationAgainstClass(userLocation);
    }
  };

  const handleCheckIn = () => {
    if (!isWithinRange) {
      alert("You are not within the class location range");
      return;
    }

    const time = new Date().toLocaleTimeString();

    setCheckInTime(time);
    setCurrentStatus("checked_in");

    setAttendanceRecords(prev => [
      {
        id: prev.length + 1,
        date: new Date().toISOString().slice(0, 10),
        check_in: time,
        check_out: null,
        status: "present",
        location_match: true,
        coordinates: userLocation || undefined
      },
      ...prev
    ]);
  };

  const handleCheckOut = () => {
    if (!checkInTime) return;

    const time = new Date().toLocaleTimeString();

    setCurrentStatus("checked_out");

    setAttendanceRecords(prev => {
      const updated = [...prev];
      if (updated[0]) {
        updated[0].check_out = time;
      }
      return updated;
    });
  };

  const onMapLoad = useCallback((map: google.maps.Map) => {
    // Map loaded successfully
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">Teacher Attendance</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* MAP */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {apiKey ? (
              <LoadScript googleMapsApiKey={apiKey}>
                <GoogleMap
                  mapContainerStyle={containerStyle}
                  center={mapCenter}
                  zoom={16}
                  onLoad={onMapLoad}
                >
                  {/* User Location Marker */}
                  {userLocation && (
                    <Marker
                      position={userLocation}
                      icon={{
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 8,
                        fillColor: '#4285F4',
                        fillOpacity: 1,
                        strokeColor: '#ffffff',
                        strokeWeight: 2,
                      }}
                      title="Your Location"
                    />
                  )}

                  {/* Class Location Marker and Circle */}
                  {selectedClass && (
                    <>
                      <Marker
                        position={selectedClass.coordinates}
                        icon={{
                          path: google.maps.SymbolPath.CIRCLE,
                          scale: 10,
                          fillColor: '#EA4335',
                          fillOpacity: 1,
                          strokeColor: '#ffffff',
                          strokeWeight: 2,
                        }}
                        title={selectedClass.name}
                      />
                      <Circle
                        center={selectedClass.coordinates}
                        radius={selectedClass.radius}
                        options={{
                          fillColor: isWithinRange ? '#34A853' : '#EA4335',
                          fillOpacity: 0.2,
                          strokeColor: isWithinRange ? '#34A853' : '#EA4335',
                          strokeOpacity: 0.8,
                          strokeWeight: 2,
                        }}
                      />
                    </>
                  )}
                </GoogleMap>
              </LoadScript>
            ) : (
              <div className="h-96 flex items-center justify-center bg-gray-100">
                <div className="text-center p-4">
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">
                    Google Maps API Key Missing
                  </h3>
                  <p className="text-gray-500 text-sm">
                    Add VITE_GOOGLE_MAPS_API_KEY to your .env file
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* CONTROLS */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Class
                </label>
                <select
                  className="w-full border border-gray-300 rounded-md p-2.5 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  onChange={(e) => {
                    const cls = classLocations.find(c => c.id === Number(e.target.value));
                    if (cls) handleClassSelect(cls);
                  }}
                  defaultValue=""
                >
                  <option value="" disabled>Select a class</option>
                  {classLocations.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.building} {c.room}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={getCurrentLocation}
                disabled={isLoadingLocation}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2.5 rounded-md flex items-center justify-center gap-2 transition-colors"
              >
                {isLoadingLocation ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    Getting Location...
                  </>
                ) : (
                  <>
                    <RefreshCw size={20} />
                    Refresh Location
                  </>
                )}
              </button>

              {locationError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md text-sm">
                  {locationError}
                </div>
              )}

              {userLocation && (
                <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-md text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <MapPin size={16} />
                    <strong>Your Location:</strong>
                  </div>
                  <div className="text-xs">
                    Lat: {userLocation.lat.toFixed(6)}, Lng: {userLocation.lng.toFixed(6)}
                    <br />
                    Accuracy: ±{userLocation.accuracy.toFixed(0)}m
                  </div>
                </div>
              )}

              {distance !== null && selectedClass && (
                <div className={`border px-4 py-3 rounded-md ${
                  isWithinRange 
                    ? 'bg-green-50 border-green-200 text-green-700'
                    : 'bg-red-50 border-red-200 text-red-700'
                }`}>
                  <strong>Distance to {selectedClass.name}:</strong>
                  <div className="text-lg font-bold mt-1">
                    {distance.toFixed(2)} meters
                  </div>
                  <div className="text-sm mt-1">
                    {isWithinRange ? '✅ Within Range' : '❌ Out of Range'}
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  disabled={!isWithinRange || currentStatus !== "not_checked_in"}
                  onClick={handleCheckIn}
                  className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white px-4 py-2.5 rounded-md flex items-center justify-center gap-2 transition-colors"
                >
                  <CheckCircle size={20} />
                  Check In
                </button>

                <button
                  disabled={currentStatus !== "checked_in"}
                  onClick={handleCheckOut}
                  className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white px-4 py-2.5 rounded-md flex items-center justify-center gap-2 transition-colors"
                >
                  <XCircle size={20} />
                  Check Out
                </button>
              </div>

              {currentStatus !== 'not_checked_in' && (
                <div className="bg-gray-50 border border-gray-200 px-4 py-3 rounded-md text-sm">
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <strong>Status:</strong> {currentStatus === 'checked_in' ? 'Checked In' : 'Checked Out'}
                  </div>
                  {checkInTime && (
                    <div className="text-xs text-gray-600 mt-1">
                      Check-in time: {checkInTime}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Attendance Records */}
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4 text-gray-800">Attendance Records</h2>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100 border-b">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Date</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Check In</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Check Out</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Location</th>
                </tr>
              </thead>

              <tbody>
                {attendanceRecords.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                      No attendance records yet
                    </td>
                  </tr>
                ) : (
                  attendanceRecords.map(r => (
                    <tr key={r.id} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm">{r.date}</td>
                      <td className="px-4 py-3 text-sm">{r.check_in}</td>
                      <td className="px-4 py-3 text-sm">{r.check_out || "—"}</td>
                      <td className="px-4 py-3">
                        <span className="inline-block px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800 capitalize">
                          {r.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {r.location_match ? (
                          <span className="text-green-600">✓ Verified</span>
                        ) : (
                          <span className="text-red-600">✗ Not Verified</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}