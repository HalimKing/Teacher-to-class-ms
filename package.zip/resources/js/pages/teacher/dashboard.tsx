import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head } from '@inertiajs/react';
import { 
  GraduationCap, Users, Star, BookOpen, Activity, Search, 
  MapPin, Calendar, Clock, TrendingUp, BarChart3, PieChart, 
  Download, Target, Award, TrendingDown, Bell, MessageSquare,
  Video, FileText, BookMarked, Users as StudentsIcon, CheckCircle,
  AlertCircle, Clock as ClockIcon, ChevronRight, User, Mail,
  Phone, Award as Trophy, Brain, Zap, Coffee, BookOpen as BookIcon,
  Shield, Globe, MailCheck, CalendarDays, Timer, BookmarkCheck,
  Upload
} from 'lucide-react';
import { useState, useMemo } from 'react';

// Import Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const breadcrumbs: BreadcrumbItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
  },
];

// Teacher profile data
const teacherProfile = {
  name: 'Dr. Sarah Johnson',
  email: 'sarah.johnson@university.edu',
  phone: '+1 (555) 123-4567',
  subject: 'Computer Science',
  faculty: 'Faculty of Computing',
  department: 'Software Engineering',
  office: 'Building A, Room 315',
  experience: '8 years',
  rating: 4.8,
  totalStudents: 156,
  avatar: 'bg-gradient-to-r from-purple-500 to-indigo-600',
  status: 'teaching',
  nextClass: 'Data Structures - 10:00 AM',
  upcomingOfficeHours: 'Today, 2:00 PM - 4:00 PM'
};

const upcomingClasses = [
  {
    id: 1,
    course: 'Data Structures',
    code: 'CS201',
    time: '10:00 AM - 11:30 AM',
    room: 'A-101',
    type: 'Lecture',
    students: 45,
    duration: '90 min',
    status: 'upcoming',
    materials: 'Chapter 4: Trees'
  },
  {
    id: 2,
    course: 'Algorithms',
    code: 'CS301',
    time: '2:00 PM - 3:30 PM',
    room: 'B-205',
    type: 'Lab Session',
    students: 30,
    duration: '90 min',
    status: 'upcoming',
    materials: 'Sorting Algorithms Lab'
  },
  {
    id: 3,
    course: 'Database Systems',
    code: 'CS401',
    time: 'Tomorrow, 9:00 AM',
    room: 'C-102',
    type: 'Lecture',
    students: 52,
    duration: '90 min',
    status: 'upcoming',
    materials: 'SQL Queries Practice'
  }
];

const recentActivities = [
  {
    id: 1,
    title: 'Graded Assignment #3',
    description: 'Data Structures - Linked Lists',
    time: '2 hours ago',
    icon: CheckCircle,
    iconColor: 'text-green-500',
    iconBg: 'bg-green-100 dark:bg-green-900/20'
  },
  {
    id: 2,
    title: 'Uploaded Lecture Notes',
    description: 'Algorithms - Dynamic Programming',
    time: 'Yesterday',
    icon: Upload,
    iconColor: 'text-blue-500',
    iconBg: 'bg-blue-100 dark:bg-blue-900/20'
  },
  {
    id: 3,
    title: 'Office Hours Completed',
    description: '5 students attended',
    time: 'Yesterday',
    icon: Users,
    iconColor: 'text-purple-500',
    iconBg: 'bg-purple-100 dark:bg-purple-900/20'
  },
  {
    id: 4,
    title: 'Research Paper Submitted',
    description: 'IEEE Conference Submission',
    time: '3 days ago',
    icon: FileText,
    iconColor: 'text-orange-500',
    iconBg: 'bg-orange-100 dark:bg-orange-900/20'
  }
];

const quickActions = [
  {
    id: 1,
    title: 'Start Class',
    icon: Video,
    variant: 'primary',
    action: '/classes/start'
  },
  {
    id: 2,
    title: 'Upload Materials',
    icon: Upload,
    variant: 'secondary',
    action: '/materials/upload'
  },
  {
    id: 3,
    title: 'Check Messages',
    icon: MessageSquare,
    variant: 'secondary',
    action: '/messages'
  },
  {
    id: 4,
    title: 'Schedule Office Hours',
    icon: CalendarDays,
    variant: 'secondary',
    action: '/office-hours/schedule'
  }
];

const performanceStats = [
  {
    title: 'Overall Rating',
    value: '4.8',
    icon: Star,
    iconColor: 'text-yellow-500',
    iconBg: 'bg-yellow-100 dark:bg-yellow-900/20',
    change: '+0.2',
    changeType: 'positive',
    description: 'Based on 156 student reviews'
  },
  {
    title: 'Attendance Rate',
    value: '94%',
    icon: Users,
    iconColor: 'text-green-500',
    iconBg: 'bg-green-100 dark:bg-green-900/20',
    change: '+3.2%',
    changeType: 'positive',
    description: 'Student attendance average'
  },
  {
    title: 'Avg. Grade',
    value: 'B+',
    icon: Trophy,
    iconColor: 'text-blue-500',
    iconBg: 'bg-blue-100 dark:bg-blue-900/20',
    change: '±0.0',
    changeType: 'neutral',
    description: 'Class average this semester'
  },
  {
    title: 'Response Time',
    value: '2.4h',
    icon: Clock,
    iconColor: 'text-purple-500',
    iconBg: 'bg-purple-100 dark:bg-purple-900/20',
    change: '-0.5h',
    changeType: 'positive',
    description: 'Avg. time to respond to students'
  }
];

const coursePerformance = [
  {
    id: 1,
    course: 'Data Structures',
    enrollment: 45,
    avgGrade: 84,
    completion: 92,
    trend: 'up'
  },
  {
    id: 2,
    course: 'Algorithms',
    enrollment: 30,
    avgGrade: 81,
    completion: 88,
    trend: 'up'
  },
  {
    id: 3,
    course: 'Database Systems',
    enrollment: 52,
    avgGrade: 79,
    completion: 85,
    trend: 'stable'
  }
];

const studentEngagement = {
  highlyEngaged: 68,
  moderatelyEngaged: 25,
  needsAttention: 7
};

const timeFilters = [
  { id: 'today', label: 'Today' },
  { id: 'week', label: 'This Week' },
  { id: 'month', label: 'This Month' },
  { id: 'semester', label: 'This Semester' },
];

// Mock attendance data
const generateAttendanceData = (timeRange: string) => {
  switch(timeRange) {
    case 'today':
      return {
        labels: ['9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM'],
        attendance: [92, 94, 96, 95, 93, 94, 95]
      };
    case 'week':
      return {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        attendance: [91, 93, 94, 95, 93]
      };
    case 'month':
    default:
      return {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        attendance: [90, 92, 94, 95]
      };
  }
};

const generateGradeDistribution = () => {
  return {
    labels: ['A (90-100)', 'B (80-89)', 'C (70-79)', 'D (60-69)', 'F (<60)'],
    datasets: [
      {
        data: [25, 40, 20, 10, 5],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)',  // Green for A
          'rgba(59, 130, 246, 0.8)',   // Blue for B
          'rgba(245, 158, 11, 0.8)',   // Orange for C
          'rgba(139, 92, 246, 0.8)',   // Purple for D
          'rgba(239, 68, 68, 0.8)',    // Red for F
        ],
        borderColor: [
          'rgb(16, 185, 129)',
          'rgb(59, 130, 246)',
          'rgb(245, 158, 11)',
          'rgb(139, 92, 246)',
          'rgb(239, 68, 68)',
        ],
        borderWidth: 1,
      },
    ],
  };
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
};

export default function TeacherDashboard() {
  const [timeFilter, setTimeFilter] = useState('week');
  const [activeTab, setActiveTab] = useState('overview');

  // Generate chart data based on time filter
  const attendanceData = useMemo(() => {
    const data = generateAttendanceData(timeFilter);
    
    return {
      labels: data.labels,
      datasets: [
        {
          label: 'Attendance Rate (%)',
          data: data.attendance,
          borderColor: 'rgb(16, 185, 129)',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          fill: true,
          tension: 0.4,
        }
      ],
    };
  }, [timeFilter]);

  const gradeDistributionData = useMemo(() => generateGradeDistribution(), []);

  const engagementData = {
    labels: ['Highly Engaged', 'Moderately Engaged', 'Needs Attention'],
    datasets: [
      {
        data: [
          studentEngagement.highlyEngaged,
          studentEngagement.moderatelyEngaged,
          studentEngagement.needsAttention
        ],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(239, 68, 68, 0.8)'
        ],
        borderColor: [
          'rgb(16, 185, 129)',
          'rgb(59, 130, 246)',
          'rgb(239, 68, 68)'
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <AppLayout breadcrumbs={breadcrumbs}>
      <Head title="Teacher Dashboard" />
      <div className="flex h-full flex-1 flex-col gap-6 rounded-xl p-4 overflow-x-auto">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-700 rounded-2xl p-6 text-white">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-20 h-20 rounded-2xl ${teacherProfile.avatar} flex items-center justify-center text-white text-2xl font-bold`}>
                SJ
              </div>
              <div>
                <h1 className="text-2xl font-bold">Welcome back, {teacherProfile.name}</h1>
                <p className="text-purple-100 mt-1">{teacherProfile.subject} • {teacherProfile.department}</p>
                <div className="flex items-center gap-4 mt-3">
                  <div className="flex items-center gap-2">
                    <ClockIcon className="h-4 w-4" />
                    <span className="text-sm">Next: {teacherProfile.nextClass}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span className="text-sm">{teacherProfile.totalStudents} Students</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors">
                <Bell className="h-4 w-4 inline mr-2" />
                Notifications
              </button>
              <button className="px-4 py-2 bg-white text-purple-700 hover:bg-white/90 rounded-lg text-sm font-medium transition-colors font-semibold">
                Start Today's Class
              </button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4">
          {performanceStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="relative overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border bg-white dark:bg-sidebar-accent p-5"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium text-sidebar-foreground/70 dark:text-sidebar-foreground/70">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-sidebar-foreground dark:text-sidebar-foreground mt-1">
                      {stat.value}
                    </p>
                    <div className={`flex items-center gap-1 mt-2 text-sm ${
                      stat.changeType === 'positive' ? 'text-green-600' : 
                      stat.changeType === 'negative' ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {stat.changeType === 'positive' && <TrendingUp className="h-4 w-4" />}
                      {stat.changeType === 'negative' && <TrendingDown className="h-4 w-4" />}
                      <span>{stat.change}</span>
                      <span className="text-sidebar-foreground/50 text-xs ml-2">{stat.description}</span>
                    </div>
                  </div>
                  <div className={`p-3 rounded-xl ${stat.iconBg}`}>
                    <Icon className={`h-6 w-6 ${stat.iconColor}`} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Upcoming Classes & Recent Activity */}
          <div className="lg:col-span-2 space-y-6">
            {/* Upcoming Classes Section */}
            <div className="bg-white dark:bg-sidebar-accent rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-sidebar-foreground dark:text-sidebar-foreground flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-blue-500" />
                    Upcoming Classes
                  </h2>
                  <p className="text-sm text-sidebar-foreground/60 dark:text-sidebar-foreground/60 mt-1">
                    Your schedule for today and tomorrow
                  </p>
                </div>
                <button className="px-4 py-2 text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                  View Full Schedule →
                </button>
              </div>

              <div className="space-y-4">
                {upcomingClasses.map((classItem) => (
                  <div key={classItem.id} className="border border-sidebar-border/50 rounded-xl p-4 hover:border-blue-300 dark:hover:border-blue-700 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg flex items-center justify-center">
                            <BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-sidebar-foreground dark:text-sidebar-foreground">
                              {classItem.course} ({classItem.code})
                            </h3>
                            <div className="flex items-center gap-4 mt-1">
                              <div className="flex items-center gap-1 text-sm text-sidebar-foreground/60">
                                <Clock className="h-4 w-4" />
                                {classItem.time}
                              </div>
                              <div className="flex items-center gap-1 text-sm text-sidebar-foreground/60">
                                <MapPin className="h-4 w-4" />
                                {classItem.room}
                              </div>
                              <div className="flex items-center gap-1 text-sm text-sidebar-foreground/60">
                                <StudentsIcon className="h-4 w-4" />
                                {classItem.students} students
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 pl-15">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <BookmarkCheck className="h-4 w-4 text-sidebar-foreground/60" />
                              <span className="text-sm text-sidebar-foreground/70">
                                Materials: {classItem.materials}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button className="px-3 py-1.5 text-sm bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30">
                                Prepare
                              </button>
                              <button className="px-3 py-1.5 text-sm bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700">
                                Start Class
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Charts Section */}
            <div className="bg-white dark:bg-sidebar-accent rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-sidebar-foreground dark:text-sidebar-foreground">
                    Performance Analytics
                  </h2>
                  <p className="text-sm text-sidebar-foreground/60 dark:text-sidebar-foreground/60 mt-1">
                    Track your class performance and student engagement
                  </p>
                </div>
                <div className="flex gap-2">
                  {timeFilters.map((filter) => (
                    <button
                      key={filter.id}
                      onClick={() => setTimeFilter(filter.id)}
                      className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                        timeFilter === filter.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 dark:bg-gray-800 text-sidebar-foreground dark:text-sidebar-foreground hover:bg-gray-200 dark:hover:bg-gray-700'
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Attendance Chart */}
                <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-sidebar-foreground dark:text-sidebar-foreground">
                      Attendance Rate
                    </h4>
                    <Users className="h-5 w-5 text-sidebar-foreground/60" />
                  </div>
                  <div className="h-64">
                    <Line data={attendanceData} options={chartOptions} />
                  </div>
                </div>

                {/* Grade Distribution */}
                <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-sidebar-foreground dark:text-sidebar-foreground">
                      Grade Distribution
                    </h4>
                    <Trophy className="h-5 w-5 text-sidebar-foreground/60" />
                  </div>
                  <div className="h-64">
                    <Doughnut data={gradeDistributionData} options={chartOptions} />
                  </div>
                </div>
              </div>

              {/* Course Performance Table */}
              <div className="mt-6">
                <h4 className="font-medium text-sidebar-foreground dark:text-sidebar-foreground mb-4">
                  Course Performance
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-sidebar-border/30">
                        <th className="text-left py-3 px-2 text-sm font-medium text-sidebar-foreground/70">Course</th>
                        <th className="text-left py-3 px-2 text-sm font-medium text-sidebar-foreground/70">Enrollment</th>
                        <th className="text-left py-3 px-2 text-sm font-medium text-sidebar-foreground/70">Avg. Grade</th>
                        <th className="text-left py-3 px-2 text-sm font-medium text-sidebar-foreground/70">Completion</th>
                        <th className="text-left py-3 px-2 text-sm font-medium text-sidebar-foreground/70">Trend</th>
                      </tr>
                    </thead>
                    <tbody>
                      {coursePerformance.map((course) => (
                        <tr key={course.id} className="border-b border-sidebar-border/20 last:border-b-0">
                          <td className="py-3 px-2">
                            <div className="font-medium text-sidebar-foreground dark:text-sidebar-foreground">
                              {course.course}
                            </div>
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4 text-sidebar-foreground/60" />
                              <span>{course.enrollment}</span>
                            </div>
                          </td>
                          <td className="py-3 px-2">
                            <span className="font-semibold">{course.avgGrade}%</span>
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex items-center gap-2">
                              <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                <div 
                                  className="bg-green-500 h-2 rounded-full" 
                                  style={{ width: `${course.completion}%` }}
                                ></div>
                              </div>
                              <span>{course.completion}%</span>
                            </div>
                          </td>
                          <td className="py-3 px-2">
                            {course.trend === 'up' && (
                              <div className="flex items-center gap-1 text-green-600">
                                <TrendingUp className="h-4 w-4" />
                                <span className="text-sm">Improving</span>
                              </div>
                            )}
                            {course.trend === 'stable' && (
                              <div className="flex items-center gap-1 text-blue-600">
                                <TrendingUp className="h-4 w-4" />
                                <span className="text-sm">Stable</span>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Quick Actions & Info */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white dark:bg-sidebar-accent rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6">
              <h3 className="text-lg font-semibold text-sidebar-foreground dark:text-sidebar-foreground mb-4">
                Quick Actions
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {quickActions.map((action) => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={action.id}
                      className={`flex flex-col items-center justify-center p-4 rounded-xl text-sm font-medium transition-all hover:scale-[1.02] ${
                        action.variant === 'primary'
                          ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                          : 'bg-gray-100 dark:bg-gray-800 text-sidebar-foreground dark:text-sidebar-foreground hover:bg-gray-200 dark:hover:bg-gray-700'
                      }`}
                    >
                      <Icon className="h-6 w-6 mb-2" />
                      <span className="text-center">{action.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white dark:bg-sidebar-accent rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6">
              <h3 className="text-lg font-semibold text-sidebar-foreground dark:text-sidebar-foreground mb-4">
                Recent Activity
              </h3>
              <div className="space-y-4">
                {recentActivities.map((activity) => {
                  const Icon = activity.icon;
                  return (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${activity.iconBg} flex-shrink-0`}>
                        <Icon className={`h-4 w-4 ${activity.iconColor}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sidebar-foreground dark:text-sidebar-foreground text-sm">
                          {activity.title}
                        </p>
                        <p className="text-sidebar-foreground/70 dark:text-sidebar-foreground/70 text-sm">
                          {activity.description}
                        </p>
                        <p className="text-sidebar-foreground/50 dark:text-sidebar-foreground/50 text-xs mt-1">
                          {activity.time}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Student Engagement */}
            <div className="bg-white dark:bg-sidebar-accent rounded-xl border border-sidebar-border/70 dark:border-sidebar-border p-6">
              <h3 className="text-lg font-semibold text-sidebar-foreground dark:text-sidebar-foreground mb-4">
                Student Engagement
              </h3>
              <div className="h-48">
                <Doughnut data={engagementData} options={chartOptions} />
              </div>
              <div className="space-y-2 mt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-sm text-sidebar-foreground">Highly Engaged</span>
                  </div>
                  <span className="font-medium">{studentEngagement.highlyEngaged}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span className="text-sm text-sidebar-foreground">Moderately Engaged</span>
                  </div>
                  <span className="font-medium">{studentEngagement.moderatelyEngaged}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span className="text-sm text-sidebar-foreground">Needs Attention</span>
                  </div>
                  <span className="font-medium">{studentEngagement.needsAttention}%</span>
                </div>
              </div>
            </div>

            {/* Teacher Info */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/10 dark:to-purple-900/10 rounded-xl border border-blue-100 dark:border-blue-900/20 p-6">
              <h3 className="text-lg font-semibold text-sidebar-foreground dark:text-sidebar-foreground mb-4">
                Your Information
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-sidebar-foreground/60" />
                  <span className="text-sm text-sidebar-foreground">{teacherProfile.email}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-sidebar-foreground/60" />
                  <span className="text-sm text-sidebar-foreground">{teacherProfile.phone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-sidebar-foreground/60" />
                  <span className="text-sm text-sidebar-foreground">{teacherProfile.office}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="h-4 w-4 text-sidebar-foreground/60" />
                  <span className="text-sm text-sidebar-foreground">{teacherProfile.experience} experience</span>
                </div>
              </div>
              <button className="w-full mt-4 px-4 py-2 text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-colors">
                Update Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}